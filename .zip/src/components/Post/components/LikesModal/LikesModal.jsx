import React from "react";
import { useNavigate } from "react-router-dom";

import { useLoggedInUser } from "../../../../contexts/LoggedInUserProvider";
import { useUser } from "../../../../contexts/UserProvider";

export const LikesModal = ({ post }) => {
  const navigate = useNavigate();
  const { userState } = useUser();
  const { followUser, unfollowUser, loggedInUserState } = useLoggedInUser();

  const isFollowing = (user) =>
    loggedInUserState?.following?.find(
      ({ username }) => username === user?.username
    );

  const followUnfollowHandler = (e, user) => {
    e.stopPropagation();
    const userFromAllUsers = userState?.allUsers?.find(
      ({ username }) => username === user?.username
    );
    !isFollowing(user)
      ? followUser(userFromAllUsers?._id)
      : unfollowUser(userFromAllUsers?._id);
  };

  return post?.likes?.likedBy.map((user) => (
    <div
      onClick={() => {
        navigate(`/profile/${user.username}`);
      }}
      key={user?._id}
      className="discover-user-card"
    >
      <div
        onClick={() => {
          navigate(`/profile/${user.username}`);
        }}
        className="discover-user-img-container"
      >
        <img src={user?.avatarURL} alt={user?.firstName} />
      </div>
      <div className="user-name-username-container">
        <p className="name">
          {user?.firstName} {user?.lastName}
        </p>
        <p className="username">@{user?.username}</p>
      </div>
      <div className="follow-container">
        {user?.username !== loggedInUserState?.username && (
          <button onClick={(e) => followUnfollowHandler(e, user)}>
            {!isFollowing(user) ? "Follow" : "Following"}
          </button>
        )}
      </div>
    </div>
  ));
};
